﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CatHotelManagement.Data;
using CatHotelManagement.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CatHotelManagement.Controllers
{
    [Route("[controller]")]
    public class CustomerDetailController : Controller
    {
        private readonly CatHotelContext _context;

        public CustomerDetailController(CatHotelContext context)
        {
            _context = context;
        }

        // GET: CustomerDetail
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var CustomerDetail = await _context.CustomerDetail.ToListAsync();
            return View(CustomerDetail); // Returns the list view of customerdetail
        }

        // GET: Customer/Details/5
        [HttpGet("Details/{id}")]
        public async Task<IActionResult> Details(int id)
        {
            var CustomerDetail = await _context.CustomerDetail.FindAsync(id);
            if (CustomerDetail == null)
            {
                return NotFound();
            }

            return View(CustomerDetail); // Returns the details view of a specific subject
        }

        // GET: CustomerDetail/Create
        [HttpGet("Create")]
        public IActionResult Create()
        {
            return View(); // Returns the view for creating a new subject
        }

        // POST: Subjects/Create
        [HttpPost("Create")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CustomerDetail customerdetail)
        {
            if (ModelState.IsValid)
            {
                _context.Add(customerdetail);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index)); // Redirects to the subject list
            }
            return View(customerdetail);
        }

        // GET: Subjects/Edit/5
        [HttpGet("Edit/{id}")]
        public async Task<IActionResult> Edit(int id)
        {
            var customerdetail = await _context.CustomerDetail.FindAsync(id);
            if (customerdetail == null)
            {
                return NotFound();
            }
            return View(customerdetail); // Returns the edit view for a specific subject
        }

        // POST: Subjects/Edit/5
        [HttpPost("Edit/{id}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, CustomerDetail customerdetail)
        {
            if (id != customerdetail.CatOwnerID)
            {
                return BadRequest();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(customerdetail);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!SubjectExists(id))
                    {
                        return NotFound();
                    }
                    throw;
                }
                return RedirectToAction(nameof(Index)); // Redirects to the subject list
            }
            return View(customerdetail);
        }

        // GET: Subjects/Delete/5
        [HttpGet("Delete/{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var customerdetail = await _context.CustomerDetail.FindAsync(id);
            if (customerdetail == null)
            {
                return NotFound();
            }

            return View(customerdetail); // Returns the delete confirmation view
        }

        // POST: Subjects/Delete/5
        [HttpPost("Delete/{id}"), ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var customerdetail = await _context.CustomerDetail.FindAsync(id);
            if (customerdetail != null)
            {
                _context.CustomerDetail.Remove(customerdetail);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index)); // Redirects to the subject list
        }

        private bool SubjectExists(int id)
        {
            return _context.CustomerDetail.Any(e => e.CatOwnerID == id);
        }
    }
}

