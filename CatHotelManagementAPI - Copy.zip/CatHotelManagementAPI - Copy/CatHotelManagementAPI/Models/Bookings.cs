﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CatHotelManagement.Models
{
    public class Bookings
    {
        [Key]
        public int BookingID { get; set; }


        [Required]
        [MaxLength(50)]
        public required string Service { get; set; }

        [Required]

        public DateTime CheckIn { get; set; }

        [Required]

        public DateTime CheckOut { get; set; }

    }
}
