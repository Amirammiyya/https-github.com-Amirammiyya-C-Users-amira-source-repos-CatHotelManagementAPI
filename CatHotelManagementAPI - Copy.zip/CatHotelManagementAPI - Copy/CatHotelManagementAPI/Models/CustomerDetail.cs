﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CatHotelManagement.Models
{
    public class CustomerDetail
    {
        [Key]
        public int CatOwnerID { get; set; }

        [Required]
        [MaxLength(50)]
        public required string CatOwnerName { get; set; }

        [Required]
        [MaxLength(50)]
        public required string CatBreed { get; set; }

        public int NumPhone { get; set; }

        [Required]
        [EmailAddress]
        [MaxLength(50)]
        public required string Email { get; set; }
    }
}
