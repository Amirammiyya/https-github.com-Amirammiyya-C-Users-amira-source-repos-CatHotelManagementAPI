﻿using Microsoft.EntityFrameworkCore;
using CatHotelManagement.Models;

namespace CatHotelManagement.Data
{
    public class CatHotelContext : DbContext
    {
        public CatHotelContext(DbContextOptions<CatHotelContext> options) : base(options) { }


        public DbSet<CustomerDetail> CustomerDetail { get; set; }
  
        public DbSet<Bookings> Bookings { get; set; }

    }
}